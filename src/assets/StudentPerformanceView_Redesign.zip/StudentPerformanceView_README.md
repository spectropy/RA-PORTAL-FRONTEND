# StudentPerformanceView redesign

## Files
- `StudentPerformanceView.jsx`
- `StudentPerformanceView.css`

## Main additions
- Separate student and teacher information architecture.
- Student view: latest score, overall average, accuracy, rank, progress trend, subject mastery, and next-step learning plan.
- Teacher view: trend delta, consistency index, attempt/accuracy diagnostic, intervention priorities, subject comparison, and detailed exam table.
- Responsive layout, keyboard focus styles, semantic progress bars, empty state, sticky table column, and reduced-motion support.
- Improved PDF summary and exam-history export.

## Usage

```jsx
<StudentPerformanceView
  student={student}
  school={school}
  examResults={examResults}
  teachers={teachers}
  view="student"
/>
```

Teacher dashboard:

```jsx
<StudentPerformanceView
  student={student}
  school={school}
  examResults={examResults}
  teachers={teachers}
  view="teacher"
/>
```

Demo/admin switch:

```jsx
<StudentPerformanceView
  student={student}
  school={school}
  examResults={examResults}
  teachers={teachers}
  allowViewSwitch
/>
```

## Compatibility
The component keeps the existing exam-result field names and requires only the dependencies already used by the source component: React, Recharts, jsPDF, and jspdf-autotable.

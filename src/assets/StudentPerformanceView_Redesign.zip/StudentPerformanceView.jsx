// src/components/StudentPerformanceView.jsx
// Role-aware student analytics dashboard for student, parent, and teacher views.

import React, { useMemo, useState } from "react";
import jsPDF from "jspdf";
import "jspdf-autotable";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import "./StudentPerformanceView.css";

const SUBJECTS = [
  { key: "physics", label: "Physics", short: "PHY" },
  { key: "chemistry", label: "Chemistry", short: "CHE" },
  { key: "maths", label: "Mathematics", short: "MAT" },
  { key: "biology", label: "Biology", short: "BIO" },
];

const toNum = (value) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
};

const clamp = (value, min = 0, max = 100) => Math.min(max, Math.max(min, value));

const pct = (value, digits = 1) => `${toNum(value).toFixed(digits)}%`;

const getSubjectPct = (result, subjectKey) => {
  const max = toNum(result?.[`max_marks_${subjectKey}`]);
  if (max <= 0) return null;
  return clamp((toNum(result?.[`${subjectKey}_marks`]) / max) * 100);
};

const formatDate = (dateValue) => {
  if (!dateValue) return "—";
  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) return String(dateValue);
  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(date);
};

const examName = (value) => String(value || "Untitled exam").replace(/_/g, " ");

const getBand = (score) => {
  const value = toNum(score);
  if (value >= 85) return { label: "Excellent", tone: "excellent" };
  if (value >= 70) return { label: "On track", tone: "good" };
  if (value >= 55) return { label: "Developing", tone: "watch" };
  return { label: "Needs support", tone: "risk" };
};

const getRankValue = (result) =>
  result?.class_rank ?? result?.school_rank ?? result?.all_schools_rank ?? "—";

const sortResultsNewestFirst = (results) =>
  results
    .map((result, index) => ({ result, index, time: new Date(result?.date).getTime() }))
    .sort((a, b) => {
      const aValid = Number.isFinite(a.time);
      const bValid = Number.isFinite(b.time);
      if (aValid && bValid) return b.time - a.time;
      if (aValid) return -1;
      if (bValid) return 1;
      return b.index - a.index;
    })
    .map(({ result }) => result);

const average = (values) => {
  const valid = values.filter(Number.isFinite);
  return valid.length ? valid.reduce((sum, value) => sum + value, 0) / valid.length : 0;
};

const standardDeviation = (values) => {
  const valid = values.filter(Number.isFinite);
  if (valid.length < 2) return 0;
  const mean = average(valid);
  const variance = valid.reduce((sum, value) => sum + (value - mean) ** 2, 0) / valid.length;
  return Math.sqrt(variance);
};

function buildAnalytics(examResults) {
  const sortedResults = sortResultsNewestFirst(examResults || []);
  const scores = sortedResults.map((result) => toNum(result.percentage));
  const latestExam = sortedResults[0] || null;
  const previousExam = sortedResults[1] || null;
  const bestExam = sortedResults.reduce(
    (best, current) => (!best || toNum(current.percentage) > toNum(best.percentage) ? current : best),
    null
  );

  const subjectData = SUBJECTS.map((subject) => {
    const subjectScores = sortedResults
      .map((result) => getSubjectPct(result, subject.key))
      .filter((value) => value !== null);

    const recent = subjectScores[0] ?? 0;
    const previous = subjectScores[1] ?? recent;

    return {
      ...subject,
      average: Number(average(subjectScores).toFixed(1)),
      latest: Number(recent.toFixed(1)),
      change: Number((recent - previous).toFixed(1)),
      examCount: subjectScores.length,
    };
  });

  const rankedSubjects = [...subjectData]
    .filter((subject) => subject.examCount > 0)
    .sort((a, b) => b.average - a.average);

  const totalCorrect = sortedResults.reduce((sum, result) => sum + toNum(result.correct_answers), 0);
  const totalWrong = sortedResults.reduce((sum, result) => sum + toNum(result.wrong_answers), 0);
  const totalUnattempted = sortedResults.reduce((sum, result) => sum + toNum(result.unattempted), 0);
  const answered = totalCorrect + totalWrong;
  const totalQuestions = answered + totalUnattempted;

  const overallAverage = average(scores);
  const trendDelta = latestExam && previousExam
    ? toNum(latestExam.percentage) - toNum(previousExam.percentage)
    : 0;
  const scoreSpread = scores.length ? Math.max(...scores) - Math.min(...scores) : 0;
  const consistency = clamp(100 - standardDeviation(scores) * 2.2);
  const accuracy = answered ? (totalCorrect / answered) * 100 : 0;
  const attemptRate = totalQuestions ? (answered / totalQuestions) * 100 : 0;

  const trendData = [...sortedResults]
    .reverse()
    .map((result, index) => ({
      index: index + 1,
      exam: examName(result.exam),
      shortExam: examName(result.exam).slice(0, 14),
      date: formatDate(result.date),
      percentage: Number(toNum(result.percentage).toFixed(1)),
      classRank: result.class_rank ?? null,
    }));

  return {
    sortedResults,
    latestExam,
    previousExam,
    bestExam,
    subjectData,
    strengthSubject: rankedSubjects[0] || null,
    focusSubject: rankedSubjects[rankedSubjects.length - 1] || null,
    overallAverage,
    trendDelta,
    scoreSpread,
    consistency,
    accuracy,
    attemptRate,
    trendData,
    totalCorrect,
    totalWrong,
    totalUnattempted,
  };
}

function buildStudentActions(analytics) {
  const actions = [];
  const focus = analytics.focusSubject;

  if (focus) {
    actions.push({
      title: `Prioritise ${focus.label}`,
      detail: `Current cumulative mastery is ${pct(focus.average)}. Start with error review, then practise one focused topic set.`,
      tone: "focus",
    });
  }

  if (analytics.accuracy < 75) {
    actions.push({
      title: "Improve answer accuracy",
      detail: `Accuracy is ${pct(analytics.accuracy)}. Mark every error as concept, calculation, or reading error before the next test.`,
      tone: "accuracy",
    });
  } else if (analytics.attemptRate < 85) {
    actions.push({
      title: "Attempt more confidently",
      detail: `Attempt rate is ${pct(analytics.attemptRate)}. Use a two-pass strategy: secure questions first, then return to difficult ones.`,
      tone: "attempt",
    });
  } else {
    actions.push({
      title: "Protect your momentum",
      detail: "Keep a short weekly revision cycle and revisit the weakest two questions from every exam.",
      tone: "momentum",
    });
  }

  return actions.slice(0, 2);
}

function buildTeacherFlags(analytics) {
  const flags = [];

  if (analytics.focusSubject && analytics.focusSubject.average < 60) {
    flags.push({
      priority: "High",
      signal: `${analytics.focusSubject.label} mastery`,
      evidence: pct(analytics.focusSubject.average),
      action: "Assign a targeted diagnostic and a short remediation cycle.",
      tone: "risk",
    });
  }

  if (analytics.accuracy < 70) {
    flags.push({
      priority: "High",
      signal: "Answer accuracy",
      evidence: pct(analytics.accuracy),
      action: "Review misconception patterns and calculation errors.",
      tone: "risk",
    });
  }

  if (analytics.attemptRate < 80) {
    flags.push({
      priority: "Medium",
      signal: "Attempt rate",
      evidence: pct(analytics.attemptRate),
      action: "Coach question selection, pacing, and confidence.",
      tone: "watch",
    });
  }

  if (analytics.trendDelta < -5) {
    flags.push({
      priority: "Medium",
      signal: "Recent score trend",
      evidence: `${analytics.trendDelta.toFixed(1)} pts`,
      action: "Check recent syllabus load, attendance, and preparation gaps.",
      tone: "watch",
    });
  }

  if (analytics.consistency < 70) {
    flags.push({
      priority: "Medium",
      signal: "Performance consistency",
      evidence: pct(analytics.consistency),
      action: "Use smaller, more frequent checks to stabilise performance.",
      tone: "watch",
    });
  }

  if (!flags.length) {
    flags.push({
      priority: "Enrichment",
      signal: "Overall learning profile",
      evidence: "Stable",
      action: "Maintain challenge level and add higher-order application work.",
      tone: "good",
    });
  }

  return flags;
}

function generatePDF(student, school, analytics) {
  const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
  const pageWidth = doc.internal.pageSize.width;
  const navy = [22, 45, 78];
  const blue = [37, 99, 235];
  const pale = [239, 246, 255];
  const dark = [15, 23, 42];

  doc.setFillColor(...navy);
  doc.rect(0, 0, pageWidth, 30, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(17);
  doc.text(school?.school_name || student?.school_name || "School", 14, 14);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(`${school?.area ? `${school.area}  •  ` : ""}Student Performance Report`, 14, 22);
  doc.text("SPECTROPY Learning Analytics", pageWidth - 14, 18, { align: "right" });

  doc.setTextColor(...dark);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.text(student?.name || "Student", 14, 43);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.text(
    `Roll No: ${student?.roll_no || student?.student_id || "—"}   •   Class: ${student?.class || "—"}-${student?.section || "—"}`,
    14,
    50
  );

  const summaryCards = [
    ["Latest score", analytics.latestExam ? pct(analytics.latestExam.percentage) : "—"],
    ["Overall average", pct(analytics.overallAverage)],
    ["Accuracy", pct(analytics.accuracy)],
    ["Attempt rate", pct(analytics.attemptRate)],
    ["Strength", analytics.strengthSubject?.label || "—"],
    ["Focus area", analytics.focusSubject?.label || "—"],
  ];

  summaryCards.forEach(([label, value], index) => {
    const x = 14 + index * 46;
    doc.setFillColor(...pale);
    doc.roundedRect(x, 58, 42, 22, 2, 2, "F");
    doc.setTextColor(71, 85, 105);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.text(label, x + 4, 66);
    doc.setTextColor(...dark);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(13);
    doc.text(String(value), x + 4, 75);
  });

  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.text("Subject mastery", 14, 94);

  analytics.subjectData.forEach((subject, index) => {
    const y = 104 + index * 14;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(...dark);
    doc.text(subject.label, 14, y + 5);
    doc.setFillColor(226, 232, 240);
    doc.roundedRect(48, y, 105, 6, 2, 2, "F");
    doc.setFillColor(...blue);
    doc.roundedRect(48, y, Math.max(2, 105 * (subject.average / 100)), 6, 2, 2, "F");
    doc.setFont("helvetica", "bold");
    doc.text(pct(subject.average), 158, y + 5);
  });

  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.text("Performance summary", 180, 94);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  const summaryText = [
    `Best exam: ${analytics.bestExam ? `${examName(analytics.bestExam.exam)} (${pct(analytics.bestExam.percentage)})` : "—"}`,
    `Recent change: ${analytics.trendDelta >= 0 ? "+" : ""}${analytics.trendDelta.toFixed(1)} points`,
    `Consistency index: ${pct(analytics.consistency)}`,
    `Score spread: ${analytics.scoreSpread.toFixed(1)} points`,
  ];
  summaryText.forEach((line, index) => doc.text(line, 180, 106 + index * 10));

  doc.addPage();
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.setTextColor(...dark);
  doc.text("Exam history", 14, 16);

  const rows = analytics.sortedResults.map((result) => [
    formatDate(result.date),
    examName(result.exam),
    result.program || "—",
    Math.round(toNum(result.correct_answers)),
    Math.round(toNum(result.wrong_answers)),
    Math.round(toNum(result.unattempted)),
    ...SUBJECTS.map((subject) => {
      const subjectPct = getSubjectPct(result, subject.key);
      return subjectPct === null ? "—" : pct(subjectPct, 0);
    }),
    pct(result.percentage),
    result.class_rank ?? "—",
    result.school_rank ?? "—",
    result.all_schools_rank ?? "—",
  ]);

  doc.autoTable({
    head: [[
      "Date",
      "Exam",
      "Program",
      "Correct",
      "Wrong",
      "Skipped",
      "Physics",
      "Chemistry",
      "Maths",
      "Biology",
      "Score",
      "Class rank",
      "School rank",
      "All-schools rank",
    ]],
    body: rows,
    startY: 22,
    theme: "grid",
    styles: { fontSize: 8, cellPadding: 2, textColor: dark },
    headStyles: { fillColor: navy, textColor: 255, fontStyle: "bold", halign: "center" },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    margin: { left: 8, right: 8 },
  });

  const safeName = String(student?.name || "Student").replace(/[^a-z0-9]+/gi, "_");
  doc.save(`Performance_Report_${safeName}_${new Date().toISOString().slice(0, 10)}.pdf`);
}

function MetricCard({ label, value, helper, tone = "neutral", badge }) {
  return (
    <article className={`sp-metric sp-tone-${tone}`}>
      <div className="sp-metric-topline">
        <span className="sp-eyebrow">{label}</span>
        {badge ? <span className={`sp-badge sp-badge-${tone}`}>{badge}</span> : null}
      </div>
      <strong className="sp-metric-value">{value}</strong>
      <span className="sp-metric-helper">{helper}</span>
    </article>
  );
}

function SubjectMastery({ subjectData, compact = false }) {
  return (
    <div className={`sp-subject-list ${compact ? "sp-subject-list-compact" : ""}`}>
      {subjectData.map((subject) => {
        const band = getBand(subject.average);
        return (
          <div className="sp-subject-row" key={subject.key}>
            <div className="sp-subject-heading">
              <div>
                <strong>{subject.label}</strong>
                <span>{subject.examCount ? `${subject.examCount} exam${subject.examCount === 1 ? "" : "s"}` : "No marks recorded"}</span>
              </div>
              <div className="sp-subject-score">
                <strong>{pct(subject.average)}</strong>
                {subject.examCount > 1 ? (
                  <span className={subject.change >= 0 ? "sp-positive" : "sp-negative"}>
                    {subject.change >= 0 ? "+" : ""}{subject.change.toFixed(1)}
                  </span>
                ) : null}
              </div>
            </div>
            <div
              className="sp-progress-track"
              role="progressbar"
              aria-label={`${subject.label} average`}
              aria-valuemin="0"
              aria-valuemax="100"
              aria-valuenow={subject.average}
            >
              <span
                className={`sp-progress-fill sp-progress-${band.tone}`}
                style={{ width: `${clamp(subject.average)}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}

function EmptyState() {
  return (
    <section className="sp-empty-state">
      <div className="sp-empty-icon" aria-hidden="true">↗</div>
      <h3>Performance insights will appear here</h3>
      <p>Add the first exam result to unlock score trends, subject mastery, accuracy, and teacher intervention signals.</p>
    </section>
  );
}

function StudentView({ analytics, teachers }) {
  const latestBand = getBand(analytics.latestExam?.percentage || 0);
  const actions = buildStudentActions(analytics);

  return (
    <>
      <section className="sp-kpi-grid" aria-label="Student performance summary">
        <MetricCard
          label="Latest score"
          value={analytics.latestExam ? pct(analytics.latestExam.percentage) : "—"}
          helper={analytics.latestExam ? `${examName(analytics.latestExam.exam)} • ${formatDate(analytics.latestExam.date)}` : "No exam recorded"}
          tone={latestBand.tone}
          badge={latestBand.label}
        />
        <MetricCard
          label="Overall average"
          value={pct(analytics.overallAverage)}
          helper={`Across ${analytics.sortedResults.length} exam${analytics.sortedResults.length === 1 ? "" : "s"}`}
          tone="good"
        />
        <MetricCard
          label="Answer accuracy"
          value={pct(analytics.accuracy)}
          helper={`${Math.round(analytics.totalCorrect)} correct • ${Math.round(analytics.totalWrong)} incorrect`}
          tone={analytics.accuracy >= 75 ? "excellent" : analytics.accuracy >= 60 ? "watch" : "risk"}
        />
        <MetricCard
          label="Class rank"
          value={analytics.latestExam?.class_rank ?? "—"}
          helper="Latest available exam rank"
          tone="neutral"
        />
      </section>

      <section className="sp-two-column sp-main-grid">
        <article className="sp-panel sp-chart-panel">
          <div className="sp-section-heading">
            <div>
              <span className="sp-eyebrow">Progress</span>
              <h3>Score trend</h3>
            </div>
            <div className={`sp-trend-chip ${analytics.trendDelta >= 0 ? "sp-trend-up" : "sp-trend-down"}`}>
              {analytics.trendDelta >= 0 ? "↑" : "↓"} {Math.abs(analytics.trendDelta).toFixed(1)} pts
            </div>
          </div>
          <div className="sp-chart" aria-label="Exam score trend chart">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={analytics.trendData} margin={{ top: 18, right: 20, left: -18, bottom: 8 }}>
                <CartesianGrid strokeDasharray="4 5" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="shortExam" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} tickFormatter={(value) => `${value}%`} tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip
                  formatter={(value) => [`${value}%`, "Score"]}
                  labelFormatter={(_, payload) => payload?.[0]?.payload?.exam || "Exam"}
                  contentStyle={{ borderRadius: 12, borderColor: "#e2e8f0", boxShadow: "0 12px 30px rgba(15,23,42,.12)" }}
                />
                <ReferenceLine y={70} stroke="#94a3b8" strokeDasharray="5 5" />
                <Line type="monotone" dataKey="percentage" stroke="#2563eb" strokeWidth={3} dot={{ r: 4, fill: "#ffffff", strokeWidth: 3 }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </article>

        <article className="sp-panel">
          <div className="sp-section-heading">
            <div>
              <span className="sp-eyebrow">Subject profile</span>
              <h3>Mastery by subject</h3>
            </div>
          </div>
          <SubjectMastery subjectData={analytics.subjectData} />
        </article>
      </section>

      <section className="sp-two-column">
        <article className="sp-panel sp-action-panel">
          <div className="sp-section-heading">
            <div>
              <span className="sp-eyebrow">Recommended next step</span>
              <h3>Your learning plan</h3>
            </div>
          </div>
          <div className="sp-action-list">
            {actions.map((action, index) => (
              <div className={`sp-action-item sp-action-${action.tone}`} key={action.title}>
                <span className="sp-action-number">{index + 1}</span>
                <div>
                  <strong>{action.title}</strong>
                  <p>{action.detail}</p>
                </div>
              </div>
            ))}
          </div>
        </article>

        <article className="sp-panel sp-highlight-panel">
          <span className="sp-eyebrow">Performance highlights</span>
          <div className="sp-highlight-grid">
            <div>
              <span>Strongest subject</span>
              <strong>{analytics.strengthSubject?.label || "—"}</strong>
              <small>{analytics.strengthSubject ? pct(analytics.strengthSubject.average) : "No data"}</small>
            </div>
            <div>
              <span>Best exam</span>
              <strong>{analytics.bestExam ? examName(analytics.bestExam.exam) : "—"}</strong>
              <small>{analytics.bestExam ? pct(analytics.bestExam.percentage) : "No data"}</small>
            </div>
            <div>
              <span>Attempt rate</span>
              <strong>{pct(analytics.attemptRate)}</strong>
              <small>{Math.round(analytics.totalUnattempted)} questions skipped</small>
            </div>
          </div>
        </article>
      </section>

      <RecentExamCards results={analytics.sortedResults.slice(0, 4)} />
      <TeacherSupport teachers={teachers} />
    </>
  );
}

function TeacherView({ analytics, teachers }) {
  const flags = buildTeacherFlags(analytics);

  return (
    <>
      <section className="sp-kpi-grid sp-teacher-kpis" aria-label="Teacher analytics summary">
        <MetricCard
          label="Overall average"
          value={pct(analytics.overallAverage)}
          helper={`Across ${analytics.sortedResults.length} assessed exams`}
          tone={getBand(analytics.overallAverage).tone}
        />
        <MetricCard
          label="Recent movement"
          value={`${analytics.trendDelta >= 0 ? "+" : ""}${analytics.trendDelta.toFixed(1)} pts`}
          helper="Latest score versus previous score"
          tone={analytics.trendDelta >= 0 ? "excellent" : "risk"}
        />
        <MetricCard
          label="Consistency index"
          value={pct(analytics.consistency)}
          helper={`Score spread: ${analytics.scoreSpread.toFixed(1)} points`}
          tone={analytics.consistency >= 75 ? "good" : "watch"}
        />
        <MetricCard
          label="Attempt / accuracy"
          value={`${analytics.attemptRate.toFixed(0)} / ${analytics.accuracy.toFixed(0)}`}
          helper="Attempt rate / answer accuracy"
          tone={analytics.accuracy >= 70 && analytics.attemptRate >= 80 ? "good" : "watch"}
        />
      </section>

      <section className="sp-teacher-dashboard-grid">
        <article className="sp-panel sp-chart-panel sp-teacher-trend">
          <div className="sp-section-heading">
            <div>
              <span className="sp-eyebrow">Longitudinal analysis</span>
              <h3>Exam performance trend</h3>
            </div>
            <span className="sp-note">70% reference line</span>
          </div>
          <div className="sp-chart sp-chart-tall">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={analytics.trendData} margin={{ top: 18, right: 22, left: -12, bottom: 10 }}>
                <CartesianGrid strokeDasharray="4 5" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="shortExam" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} tickFormatter={(value) => `${value}%`} tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip
                  formatter={(value, name) => [name === "percentage" ? `${value}%` : value, name === "percentage" ? "Score" : "Class rank"]}
                  labelFormatter={(_, payload) => payload?.[0]?.payload?.exam || "Exam"}
                  contentStyle={{ borderRadius: 12, borderColor: "#e2e8f0", boxShadow: "0 12px 30px rgba(15,23,42,.12)" }}
                />
                <ReferenceLine y={70} stroke="#f59e0b" strokeDasharray="5 5" />
                <Line type="monotone" dataKey="percentage" stroke="#2563eb" strokeWidth={3} dot={{ r: 4, fill: "#fff", strokeWidth: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </article>

        <article className="sp-panel sp-intervention-panel">
          <div className="sp-section-heading">
            <div>
              <span className="sp-eyebrow">Decision support</span>
              <h3>Intervention priorities</h3>
            </div>
          </div>
          <div className="sp-flag-list">
            {flags.map((flag) => (
              <div className={`sp-flag sp-flag-${flag.tone}`} key={`${flag.signal}-${flag.priority}`}>
                <div className="sp-flag-heading">
                  <span>{flag.priority}</span>
                  <strong>{flag.evidence}</strong>
                </div>
                <h4>{flag.signal}</h4>
                <p>{flag.action}</p>
              </div>
            ))}
          </div>
        </article>
      </section>

      <section className="sp-two-column">
        <article className="sp-panel">
          <div className="sp-section-heading">
            <div>
              <span className="sp-eyebrow">Cumulative diagnosis</span>
              <h3>Subject mastery</h3>
            </div>
          </div>
          <SubjectMastery subjectData={analytics.subjectData} compact />
        </article>

        <article className="sp-panel sp-chart-panel">
          <div className="sp-section-heading">
            <div>
              <span className="sp-eyebrow">Comparison</span>
              <h3>Average score by subject</h3>
            </div>
          </div>
          <div className="sp-chart">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics.subjectData} margin={{ top: 10, right: 12, left: -16, bottom: 8 }} barSize={34}>
                <CartesianGrid strokeDasharray="4 5" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="short" axisLine={false} tickLine={false} tick={{ fontSize: 11, fontWeight: 700 }} />
                <YAxis domain={[0, 100]} tickFormatter={(value) => `${value}%`} axisLine={false} tickLine={false} tick={{ fontSize: 11 }} />
                <Tooltip formatter={(value) => [`${value}%`, "Average"]} contentStyle={{ borderRadius: 12, borderColor: "#e2e8f0" }} />
                <Bar dataKey="average" fill="#0f766e" radius={[8, 8, 2, 2]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </article>
      </section>

      <ExamAnalyticsTable results={analytics.sortedResults} />
      <TeacherSupport teachers={teachers} teacherMode />
    </>
  );
}

function RecentExamCards({ results }) {
  return (
    <section className="sp-section-block">
      <div className="sp-section-heading sp-section-heading-outside">
        <div>
          <span className="sp-eyebrow">Recent activity</span>
          <h3>Latest exam results</h3>
        </div>
      </div>
      <div className="sp-exam-card-grid">
        {results.map((result, index) => {
          const band = getBand(result.percentage);
          return (
            <article className="sp-exam-card" key={`${result.exam}-${result.date}-${index}`}>
              <div className="sp-exam-card-top">
                <span>{formatDate(result.date)}</span>
                <span className={`sp-badge sp-badge-${band.tone}`}>{band.label}</span>
              </div>
              <h4>{examName(result.exam)}</h4>
              <p>{result.program || "General programme"}</p>
              <div className="sp-exam-score-row">
                <strong>{pct(result.percentage)}</strong>
                <span>Class rank {result.class_rank ?? "—"}</span>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}

function ExamAnalyticsTable({ results }) {
  return (
    <section className="sp-section-block">
      <div className="sp-section-heading sp-section-heading-outside">
        <div>
          <span className="sp-eyebrow">Detailed evidence</span>
          <h3>Exam analytics</h3>
        </div>
        <span className="sp-note">Scroll horizontally to view all columns</span>
      </div>
      <div className="sp-table-shell" tabIndex="0" aria-label="Scrollable exam analytics table">
        <table className="sp-table">
          <thead>
            <tr>
              <th className="sp-sticky-column">Exam</th>
              <th>Date</th>
              <th>Score</th>
              <th>Correct</th>
              <th>Wrong</th>
              <th>Skipped</th>
              {SUBJECTS.map((subject) => <th key={subject.key}>{subject.short}</th>)}
              <th>Class rank</th>
              <th>School rank</th>
              <th>All-schools rank</th>
            </tr>
          </thead>
          <tbody>
            {results.map((result, index) => {
              const band = getBand(result.percentage);
              return (
                <tr key={`${result.exam}-${result.date}-${index}`}>
                  <td className="sp-sticky-column">
                    <strong>{examName(result.exam)}</strong>
                    <span>{result.program || "—"}</span>
                  </td>
                  <td>{formatDate(result.date)}</td>
                  <td><span className={`sp-score-cell sp-score-${band.tone}`}>{pct(result.percentage)}</span></td>
                  <td>{Math.round(toNum(result.correct_answers))}</td>
                  <td>{Math.round(toNum(result.wrong_answers))}</td>
                  <td>{Math.round(toNum(result.unattempted))}</td>
                  {SUBJECTS.map((subject) => {
                    const value = getSubjectPct(result, subject.key);
                    return <td key={subject.key}>{value === null ? "—" : pct(value, 0)}</td>;
                  })}
                  <td>{result.class_rank ?? "—"}</td>
                  <td>{result.school_rank ?? "—"}</td>
                  <td>{result.all_schools_rank ?? "—"}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function TeacherSupport({ teachers, teacherMode = false }) {
  if (!teachers?.length) return null;

  return (
    <section className="sp-section-block">
      <div className="sp-section-heading sp-section-heading-outside">
        <div>
          <span className="sp-eyebrow">{teacherMode ? "Assigned faculty" : "Learning support"}</span>
          <h3>{teacherMode ? "Teaching team" : "Your subject teachers"}</h3>
        </div>
      </div>
      <div className="sp-teacher-grid">
        {teachers.map((teacher, index) => (
          <article className="sp-teacher-card" key={`${teacher.email || teacher.name}-${index}`}>
            <div className="sp-avatar" aria-hidden="true">
              {String(teacher.name || "T")
                .split(" ")
                .slice(0, 2)
                .map((part) => part[0])
                .join("")
                .toUpperCase()}
            </div>
            <div className="sp-teacher-details">
              <strong>{teacher.name || "Teacher"}</strong>
              <span>{teacher.subject || "Subject teacher"}</span>
              <div className="sp-teacher-links">
                {teacher.email ? <a href={`mailto:${teacher.email}`}>Email</a> : null}
                {teacher.phone ? <a href={`tel:${teacher.phone}`}>Call</a> : null}
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

export default function StudentPerformanceView({
  student,
  school,
  examResults = [],
  teachers = [],
  title = "Student Performance",
  onBack,
  view = "student",
  allowViewSwitch = false,
  onViewChange,
}) {
  const [localView, setLocalView] = useState(view === "teacher" ? "teacher" : "student");
  const activeView = allowViewSwitch ? localView : view === "teacher" ? "teacher" : "student";
  const analytics = useMemo(() => buildAnalytics(examResults), [examResults]);

  const setView = (nextView) => {
    setLocalView(nextView);
    onViewChange?.(nextView);
  };

  const schoolName = student?.school_name || school?.school_name || "School";
  const initials = String(student?.name || "Student")
    .split(" ")
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();

  return (
    <main className="sp-page">
      <div className="sp-container">
        <header className="sp-topbar">
          <div className="sp-topbar-left">
            {onBack ? (
              <button className="sp-button sp-button-secondary" type="button" onClick={onBack}>
                <span aria-hidden="true">←</span> Back
              </button>
            ) : null}
            <div>
              <span className="sp-school-name">{schoolName}</span>
              <h1>{title}</h1>
            </div>
          </div>

          <div className="sp-topbar-actions">
            {allowViewSwitch ? (
              <div className="sp-view-switch" role="group" aria-label="Dashboard view">
                <button
                  type="button"
                  className={activeView === "student" ? "is-active" : ""}
                  onClick={() => setView("student")}
                  aria-pressed={activeView === "student"}
                >
                  Student view
                </button>
                <button
                  type="button"
                  className={activeView === "teacher" ? "is-active" : ""}
                  onClick={() => setView("teacher")}
                  aria-pressed={activeView === "teacher"}
                >
                  Teacher view
                </button>
              </div>
            ) : null}

            {examResults.length ? (
              <button
                className="sp-button sp-button-primary"
                type="button"
                onClick={() => generatePDF(student, school, analytics)}
              >
                Download report
              </button>
            ) : null}
          </div>
        </header>

        <section className="sp-student-hero">
          <div className="sp-avatar sp-avatar-large" aria-hidden="true">{initials}</div>
          <div className="sp-student-identity">
            <span className="sp-eyebrow">Student profile</span>
            <h2>{student?.name || "Student name"}</h2>
            <div className="sp-student-meta">
              <span>Class {student?.class || "—"}-{student?.section || "—"}</span>
              <span>Roll No. {student?.roll_no || student?.student_id || "—"}</span>
              <span>{analytics.sortedResults.length} exams analysed</span>
            </div>
          </div>
          {analytics.latestExam ? (
            <div className="sp-latest-summary">
              <span>Latest assessment</span>
              <strong>{examName(analytics.latestExam.exam)}</strong>
              <small>{formatDate(analytics.latestExam.date)}</small>
            </div>
          ) : null}
        </section>

        {examResults.length ? (
          activeView === "teacher" ? (
            <TeacherView analytics={analytics} teachers={teachers} />
          ) : (
            <StudentView analytics={analytics} teachers={teachers} />
          )
        ) : (
          <EmptyState />
        )}
      </div>
    </main>
  );
}
